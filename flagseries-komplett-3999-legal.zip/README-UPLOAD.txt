Bismillah - FLAG SERIES Upload-Paket

Geändert:
- Boxpreis überall auf 39,99 € inkl. 19 % MwSt. angepasst.
- JavaScript-Preislogik auf 39.99 gesetzt.
- AGB, Impressum, Datenschutz und Widerruf professionell mit euren Daten erstellt.
- Rechtseiten liegen im Ordner /legal und nutzen ../css/style.css.

Upload-Struktur auf STRATO:
index.html
css/style.css
js/app.js
legal/impressum.html
legal/datenschutz.html
legal/agb.html
legal/widerruf.html
assets/images/  (deine vorhandenen Bilder bitte beibehalten)

Hinweis:
Die Texte sind professionelle Vorlagen, ersetzen aber keine anwaltliche Prüfung.
